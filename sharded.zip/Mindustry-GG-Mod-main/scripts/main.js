Vars.enebleConsole=true;
Blocks.powerSource.powerProduction=655360;
require('Planet');
require('lib');
require('sectorSize');